/**
 * <Car class, sets the basic values, and sets up the format for the print statement>
 * 
 * CSC 1351 Programming Project No <1>
 * Section <002>
 * 
 * @author <Logan Allsup>
 * @since <March 17 2024>
 * 
*/


 public class Car implements Comparable<Car> {
	 private String make;
	 private int year;
	 private int price;
	 /**
	  * <Car method, sets the basic values.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17 2024>
	  * 
	  */
	 public Car(String Make, int Year, int Price) {
		 make = Make;
		 year = Year;
		price = Price;
	 }
	 /**
	  * <getMake method, returns the make value.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17 2024>
	  * 
	  */
	 public String getMake() {
		 return make;
	 }
	 /**
	  * <getYear method, returns the year value.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17 2024>
	  * 
	  */
	 public int getYear() {
		 return year;
	 }
	 /**
	  * <getPrice method, returns the price value.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17 2024>
	  * 
	  */
	 public int getPrice() {
		 return price;
	 }
	 /**
	  * <compareTo method, compares the length of the make, year, and price to each input that is put in.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17 2024>
	  * 
	  */
	 public int compareTo(Car other) {
		 if (make.length() > other.make.length()) {
			 return 1;
		 }
		 else if (make.length() < other.make.length()) {
			 return -1;
		 }
		 if (Integer.compare(year,  other.year) != 0) {
			 return Integer.compare(year,  other.year);
		 }
		 
		 return Integer.compare(price,  other.price);
		 
	 }
	 /**
	  * <toString method, sets up the outline for the print statement.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17 2024>
	  * 
	  */
	 public String toString() {
		 String ret = "Make: " + make + ", Year : " + year + ", Price: " +  price + ";";
		 return ret;
	 }
 }
 
 
 
 
 