import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Paths;

/**
 * <Prog01_aOrderedList class, creates the scanner for the input file, the method does the same.>
 * 
 * CSC 1351 Programming Project No <1>
 * Section <002>
 * 
 * @author <Logan Allsup>
 * @since <March 17 2024>
 * 
*/

public class Prog01_aOrderedList {
	private static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException
	{
		File file = new File(UserPrompt);
		Scanner Scanner = new Scanner(file);
		return Scanner;

	}
	/**
	 * <PrintInputFile class, makes a PrintWriter for the input file.>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17 2024>
	 * 
	*/
private static PrintWriter PrintInputFile(String UserPrompt)  throws FileNotFoundException
{
	File file = new File(UserPrompt);
	PrintWriter Writer = new PrintWriter(file);
	return Writer;
	}
/**
 * <main method, is the main method, prints the output of the program>
 * 
 * CSC 1351 Programming Project No <1>
 * Section <002>
 * 
 * @author <Logan Allsup>
 * @since <March 17, 2024>
 * 
 */
	public static void main(String[] args) {
		Scanner inputScanner = new Scanner(System.in);
		aOrderedList List = new aOrderedList();
		Scanner success = null;
		while (success == null) {
		     System.out.println("Enter input filename:");
             String input = inputScanner.nextLine();
            try {
				success = GetInputFile(input);
			} catch (FileNotFoundException e) {
				boolean decided = false;
                 while (decided == false) {
			     System.out.println("File does not exist. Retry? Y/N");
	             String input2 = inputScanner.nextLine();
                    if (input2.charAt(0)=='Y' || input2.charAt(0)=='y') {
                    	decided = true;
                    	continue;
                    }
                    else if (input2.charAt(0)=='N' || input2.charAt(0)=='n') {
                    	System.out.println("Have a nice day.");
                    	return;
                    }
                 }
			}
		}
		 while (success.hasNextLine()) {
			 String start = success.nextLine();
	         String[] results = start.split(",");
	         if (results[0].equals("A")) {
	         List.add(new Car(results[1], Integer.parseInt(results[2]), Integer.parseInt(results[3])));
	         }
	         else if (results[0].equals("D")) {
	        	 try{
	                 int number = Integer.parseInt(results[1]);
	                 List.remove(number);
	             }
	             catch (NumberFormatException ex){
	            	 List.remove(results[1], results[2]);
	             }
	         }
	    }
		 PrintWriter success2 = null; 
		 while (success2 == null) {
		     System.out.println("Enter output filename:");
             String input = inputScanner.nextLine();
            try {
				success2 = PrintInputFile(input);
			} catch (FileNotFoundException e) {
				boolean decided = false;
                 while (decided == false) {
			     System.out.println("File does not exist. Retry? Y/N");
	             String input2 = inputScanner.nextLine();
                    if (input2.charAt(0)=='Y' || input2.charAt(0)=='y') {
                    	decided = true;
                    	continue;
                    }
                    else if (input2.charAt(0)=='N' || input2.charAt(0)=='n') {
                    	System.out.println("Have a nice day.");
                    	return;
                    }
                 }
			}
		}
		 System.out.println(List.toString());
		 success2.print(List.toString());
	}
}