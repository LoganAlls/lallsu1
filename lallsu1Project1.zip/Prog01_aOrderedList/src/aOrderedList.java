import java.util.Arrays;

/**
 * <aOrderedList class, sets the values of how the output will be.>
 * 
 * CSC 1351 Programming Project No <1>
 * Section <002>
 * 
 * @author <Logan Allsup>
 * @since <March 17 2024>
 * 
**/

public class aOrderedList {
	final int SIZEINCREMENTS = 20; //size of increments for
	//increasing ordered list
	private Comparable[] oList; //the ordered list
	private int listSize; //the size of the ordered list
	private int numObjects; //the number of objects in
	// the ordered list
	private int curr;
	private int LastReturned;
	/**
	 * <aOrderedList method, initializes the list size and increments it changes.>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	public aOrderedList()
	 {
		 numObjects = 0;
		 listSize = SIZEINCREMENTS;
		 oList = new Car[20];
		 curr = 0;
		 LastReturned = -1;
		 
	 }
	/**
	 * <comparable method, moves from value to value.>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	public Comparable<?> next() {
		if (hasNext()) {
		curr++;
		LastReturned = curr - 1;
		return get(LastReturned);
		}
		return null;
	}
	/**
	 * <hasNext method, uses true or false to determine the order of the array.>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	public boolean hasNext()
	{
		if (curr + 1 < listSize && oList[curr + 1] != null)
		{
			return true;
		}
		return false;
	}
	/**
	 * <sortRight method, sorts the Array from the right>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	 private Object sortRight (int Chosen, Comparable<?> rec) {
			 if (oList.length > Chosen + 1) {
				 if (oList[Chosen + 1] == null) {
					 if (rec == null) {
					 oList[Chosen + 1] = oList[Chosen];}
					 else {
						 oList[Chosen + 1] = rec; 
					 }
						 
					 return null;
				 }
				 else if (oList[Chosen + 1] != null) {
					 Comparable<?> save = oList[Chosen + 1];
					 if (rec == null) {
					 oList[Chosen + 1] = oList[Chosen];
					 }
					 else {
						 oList[Chosen + 1] = rec; 
					 }
						 
                     return sortRight(Chosen + 1, save);
				 }
		 }
			 return null;
	 }
	 /**
	  * <reset method, resets the placement to zero.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17, 2024>
	  * 
	  */
	 public void reset()
	 {
		 curr = 0;
	 }
	 /**
	  * <sortLeft method, sorts the array from the left.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17, 2024>
	  * 
	  */
	 private Object sortLeft (int Chosen, Car rec) {
			 if (-1 < Chosen - 1) {
				 if (oList[Chosen - 1] == null) {
					 if (rec == null) {
					 oList[Chosen - 1] = oList[Chosen];}
					 else {
						 oList[Chosen - 1] = rec; 
					 }
						 
					 return null;
				 }
				 else if (oList[Chosen - 1] != null) {
					 Comparable<?> save = oList[Chosen - 1];
					 if (rec == null) {
					 oList[Chosen - 1] = oList[Chosen];
					 }
					 else {
						 oList[Chosen - 1] = rec; 
					 }
						 
                     return sortRight(Chosen - 1, save);
				 }
		 }
			 return null;
	 }
	 /**
	  * <size method, returns the size of the list.>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17, 2024>
	  * 
	  */
	 public int size() {
		 return numObjects;
	 }
	 /**
	  * <comparable method, compares the size to the index>
	  * 
	  * CSC 1351 Programming Project No <1>
	  * Section <002>
	  * 
	  * @author <Logan Allsup>
	  * @since <March 17, 2024>
	  * 
	  */
	public Comparable<?> get(int index) {
		 if (index < listSize && index > -1 && oList[index] != null) {
			 return oList[index];
		 }
		 return null;
	 }
	/**
	 * <isEmpty method, uses true or false to determine if the list is empty>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	public Boolean isEmpty()
	{
		if (oList != null) {
			for (int i=0; i < oList.length; i++) {
			  if (oList[i] != null) {
				  return false;
			  }
			}
		}
		return true;
	}
	/**
	 * <remove method, removes the last returned value.>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	public void remove()
	{
		if (LastReturned > -1) {
			remove(LastReturned);
		}
	}
	/**
	 * <remove method, prints "removing" for the values removed>
	 * 
	 * CSC 1351 Programming Project No <1>
	 * Section <002>
	 * 
	 * @author <Logan Allsup>
	 * @since <March 17, 2024>
	 * 
	 */
	public void remove (int index) {
		if (index < listSize && index > -1 && oList[index] != null) {
			oList[index] = null;
			numObjects--;
			System.out.println("removing");
			sortLeft(numObjects + 1,null);
		 }
	}
	public void remove (String Make, String SYear)
	{
		Integer Year = Integer.parseInt(SYear);
		for (int i = 0; i < numObjects; i++) {
			if (oList[i] != null && ((Car) oList[i]).getMake().equals(Make) && Year == ((Car) oList[i]).getYear()) {
				remove(i);
				break;
			}
		}
		
	}

	public void add(Comparable<?> newObject)
	 {
		if (numObjects + 1 > listSize) {
			Comparable[] newValues = Arrays.copyOf(oList, SIZEINCREMENTS + listSize);
			listSize = oList.length;
			oList = newValues;
		}
		 int Chosen = 0;
		 for (int i = 0; i <= Math.min(Chosen + 1, listSize); i++) {
			 if (oList[i] != null && oList[i].compareTo(newObject) == -1) {
					Chosen = i;
				 break;
				}
			 else if (oList[i] == null) {
				 Chosen = i;
				 break;
			 }
		 }
		 if (oList[Chosen] != null) {
			sortRight(Chosen, null);
			 oList[Chosen] = newObject;
		 }
		 else {
			 oList[Chosen] = newObject;
		 }
		 numObjects++;

	 }
	public String toString()
	 {
		String ret = "";
		for (int i = 0; i < listSize; i++) {
			if (oList[i] != null) {
			ret += "\n" + oList[i].toString();
			}
		}
		return ret;
		
	 }
}
